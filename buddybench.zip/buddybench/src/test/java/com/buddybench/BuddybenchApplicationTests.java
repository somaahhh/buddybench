package com.buddybench;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuddybenchApplicationTests {

	@Test
	void contextLoads() {
	}

}
