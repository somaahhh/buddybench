package com.buddybench;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
@SpringBootApplication
public class BuddyBenchApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuddyBenchApplication.class, args);
        System.err.println("Welcome to BuddyBench Application...");

    }

}
