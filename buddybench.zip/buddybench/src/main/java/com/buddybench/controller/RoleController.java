package com.buddybench.controller;

public class RoleController {
}
