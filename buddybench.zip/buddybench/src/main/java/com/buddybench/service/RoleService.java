package com.buddybench.service;

import org.springframework.stereotype.Service;

@Service
public class RoleService {
}
